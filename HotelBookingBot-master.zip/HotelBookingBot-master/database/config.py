
database = 'd8loe3avga6q5a'
user = 'medjuvpxmgffdf'
password ='67f1b53a27d190e61f5b1552897fa4de529675e44296dcc5fa3943183e068789'
host = 'ec2-52-30-133-191.eu-west-1.compute.amazonaws.com'
port = '5432'
