import os

API_TOKEN = '5024666266:AAFn9d-udwkdt-MjcA6c6TOu1lVYYg0v4ZU'
